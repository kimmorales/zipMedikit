//
//  Notificacion.swift
//  MediKit
//
//  Created by administrador on 25/10/17.
//  Copyright © 2017 Tecnologico de Costa Rica. All rights reserved.
//

import Foundation

struct Notificacion {
    var id: String
    var nombreMedicamento: String
    var nombrePaciente: String
    var tipoMedicamento: String
    var cantidad: Int
    var duracionNotificacion: Int
}
