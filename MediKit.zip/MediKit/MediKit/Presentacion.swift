//
//  Presentacion.swift
//  MediKit
//
//  Created by administrador on 25/10/17.
//  Copyright © 2017 Tecnologico de Costa Rica. All rights reserved.
//

import Foundation

struct Presentacion {
    var id: String
    var nombre: String
    var descripcion: String
}
