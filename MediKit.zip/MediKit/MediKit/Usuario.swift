//
//  Usuario.swift
//  MediKit
//
//  Created by administrador on 25/10/17.
//  Copyright © 2017 Tecnologico de Costa Rica. All rights reserved.
//

import Foundation

public struct Usuario {
        public let id : String
        public let correoElectronico: String
        public let nombreUsuario: String
        public let contrasenna: String
}
