//
//  JSONParser.swift
//  MediKit
//
//  Created by Administrador on 16/10/17.
//  Copyright © 2017 Tecnologico de Costa Rica. All rights reserved.
//

import Foundation
import SwiftyJSON


struct JSONParser{

    static func parsePerfil(data: Any?) -> [Perfil]{
        
        var perfilList = [Perfil]()
        do {
            
            let json = JSON(data)
            if let responseData = json.arrayObject{
                let responseArray = responseData as! [[String:AnyObject]]
            
                for perfill in responseArray {
                    let nombreP = perfill["nombre"] as! String
                    let fechaDeNacimientoP = perfill["fechaDeNacimiento"] as! String
                    let idP = perfill["_id"] as! String
                
                    let newPerfil = Perfil(nombre: nombreP, fechaDeNacimiento: fechaDeNacimientoP,id: idP)
                perfilList.append(newPerfil)
                }
            }
        return perfilList
        }

    }
    
    static func parseUsuario(data: Any?){
        do{
            let json = JSON(data)
            if let responsaData = json.arrayObject{
                let responseArray = responsaData as! [[String : AnyObject]]
                
                for usuario in responseArray {
                    let correoElectronico = ["email"] as! String
                    let nombreDeUsuario = ["displayName"] as! String
                    let contrasenna = ["password"] as! String
                    let activo = ["activo"] as! Bool
                    let fechaRegistro = ["signupDate"] as! String
                    let perfilesAsociados = ["perfilesAsociados"] as! AnyObject
                }
            }
        }
        
    }
    
    public static func parse(medicamentosData data: Any?) -> [Medicamento] {
        var listMedicamentos = [Medicamento]()
        print(data)
        let responseArray = JSON(data).arrayObject as! [[String : AnyObject]]
        for stringMedicamento in responseArray {
            listMedicamentos.append(Medicamento(idMedicamento: stringMedicamento["_id"] as! String,nombreComercial: stringMedicamento["nombreComercial"] as! String,nombreGenerico: stringMedicamento["nombreGenerico"] as! String, descripcion: stringMedicamento["descripcion"] as! String))
            
        }
        return listMedicamentos
    }
    
    public static func parseLogin(usuariosData data: Any?) -> [Usuario] {
        let responseArray = JSON(data).arrayObject as! [[String : AnyObject]]
        var listaDePerfiles : [Perfil] = []
        var listaDeUsuarios = [Usuario]()
        var nuevoUsuario : Usuario? = nil
        for stringUsuario in responseArray {
            let id = stringUsuario["_id"] as! String
            print(id)
            let correoElectronico = stringUsuario["email"] as! String
            print(correoElectronico)
            let nombreusuario = stringUsuario["displayName"] as! String
            let contrasenna = stringUsuario["password"] as! String
            let listaPerfiles = JSON(stringUsuario["perfilesAsociados"]).arrayObject as! [[String : Any]]
            
            if listaPerfiles.count > 0 {
                for listaP in listaPerfiles {
                    let nombrePerfil = ""
                    let fechaNacimiento = ""
                    let idPerfil = listaP["_id"] as! String
                    let nuevoPerfil = Perfil(nombre: nombrePerfil, fechaDeNacimiento: fechaNacimiento, id: idPerfil)
                    listaDePerfiles.append(nuevoPerfil)
                }
            }
            nuevoUsuario = Usuario(id: id, correoElectronico: correoElectronico, nombreUsuario: nombreusuario, contrasenna: contrasenna)
            listaDeUsuarios.append(nuevoUsuario!)
            print(nuevoUsuario?.correoElectronico)
        }
        print(listaDeUsuarios.count)
        return listaDeUsuarios
        

    }
    
    
    public static func parseUsuario(usuariosData data: Any?) -> Usuario {
        //print(data)
        //var usuario: Usuario? = nil
       print(data)
        let responseArray = JSON(data).arrayObject as! [[String:Any]]
        var nuevoUsuario : Usuario? = nil
        for stringUsuario in responseArray {
            let id = stringUsuario["_id"] as! String
            let nombreusuario = stringUsuario["displayName"] as! String
            let correoElectronico = stringUsuario["email"] as! String
            let contrasenna = stringUsuario["password"] as! String
            
            nuevoUsuario = Usuario(id: id, correoElectronico: correoElectronico, nombreUsuario: nombreusuario, contrasenna: contrasenna)
            
        }
        return nuevoUsuario!
        
    }
    
    
}
