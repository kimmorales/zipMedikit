//
//  nuevoPerfilViewController.swift
//  MediKit
//
//  Created by administrador on 26/10/17.
//  Copyright © 2017 Tecnologico de Costa Rica. All rights reserved.
//

import UIKit
import Alamofire

class nuevoPerfilViewController: UIViewController, UITextFieldDelegate {
    var currentPerfil : Perfil? = nil

    @IBOutlet weak var nombreUsuario: UITextField!
    @IBOutlet weak var fechaNacimiento: UIDatePicker!

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Textfield delegate
        self.nombreUsuario.delegate = self
        
    }
    func nuevoPerfil() {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dddd = dateFormatter.string(from: fechaNacimiento.date)
        self.view.endEditing(true)
        
        let urll = Constantes.PERFIL //+ nombreUsuario.text! + dddd
        
        print(urll)
        
        
        let json: [String: Any] = ["nombre": nombreUsuario.text!,
                                   "fechaDeNacimiento":dddd]
        
        let jsonData = try? JSONSerialization.data(withJSONObject: json)
        
        // create post request
        let url = URL(string: urll)!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        // insert json data to the request
        request.httpBody = jsonData
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                print(error?.localizedDescription ?? "No data")
                return
            }
            let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
            if let responseJSON = responseJSON as? [String: Any] {
                print(responseJSON)
            }
        }
        
        task.resume()
        
        
        
    }
    
   
    
    
    
    
    
    
    @IBAction func nuevoPerfil(_ sender: AnyObject) {
        nuevoPerfil()
    }
    
    @IBAction func new(_ sender: AnyObject) {
        nuevoPerfil()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
