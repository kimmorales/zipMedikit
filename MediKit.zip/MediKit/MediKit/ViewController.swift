//
//  ViewController.swift
//  MediKit
//
//  Created by administrador on 14/9/17.
//  Copyright © 2017 Tecnologico de Costa Rica. All rights reserved.
//

import UIKit
import Alamofire
class ViewController: UIViewController {
    
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var contrassennaTextField: UITextField!
    var usuario : Usuario? = nil
    var listaUsuarios = [Usuario]()
    override func viewDidLoad() {
        super.viewDidLoad()
        emailTextField.attributedPlaceholder = NSAttributedString(string: "Usuario/Correo Electrónico", attributes: [NSForegroundColorAttributeName: UIColor.white])
        contrassennaTextField.attributedPlaceholder = NSAttributedString(string: "Contraseña", attributes: [NSForegroundColorAttributeName: UIColor.white])
        //getJSON()
        
       
    }
    @IBAction func entrar(_ sender: AnyObject) {
        
        if((emailTextField.text?.isEmpty)! || (contrassennaTextField.text?.isEmpty)!){
            alerta(nombre: "Datos incompletos", mensaje: "Debe llenar ambos campos")
        }
        else {
            let email = emailTextField.text!
            let contrasenna = contrassennaTextField.text!
            let parameters : Parameters = ["email": email, "password": contrasenna]
            let url = URL(string:Constantes.LOGIN)!
            var urlRequest = URLRequest(url: url)
            urlRequest.httpMethod = "POST"
            do{
                urlRequest.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: [])
            }
            catch{
                
            }
            urlRequest.setValue("application/json", forHTTPHeaderField:"Content-Type")
            Alamofire.request(urlRequest).responseJSON{
                response in
                if response.response?.statusCode == Constantes.OK_STATUS_CODE{
                    print(response)
                    Globals.instance.usuarioActual = JSONParser.parseUsuario(usuariosData: response.data)
                }
                else {
                    self.alerta(nombre: "Datos incorrectos", mensaje: "Los datos suministrados son incorrectos")
                }
            }
        }
    }

    
    func alerta (nombre: String, mensaje: String){
        let refreshAlert = UIAlertController(title: nombre, message: mensaje, preferredStyle: UIAlertControllerStyle.alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
            print("Handle Ok logic here")
        }))
        
        present(refreshAlert, animated: true, completion: nil)
    }

    
    @IBAction func registrarUsuario(_ sender: AnyObject) {
        self.performSegue(withIdentifier: "registroSegue", sender: self)
        
    }

    
    @IBAction func facebook(_ sender: AnyObject) {
    }
    @IBAction func google(_ sender: AnyObject) {
        
    }
    

}  
