//
//  perfil.swift
//  MediKit
//
//  Created by administrador on 19/10/17.
//  Copyright © 2017 Tecnologico de Costa Rica. All rights reserved.
//

import Foundation

public struct Perfil{
    var nombre : String
    var fechaDeNacimiento: String
    var id: String
}

